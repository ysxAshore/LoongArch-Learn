/*	$NetBSD: setjmp.h,v 1.1 1996/09/30 16:34:34 ws Exp $	*/

#define	_JBLEN	100
