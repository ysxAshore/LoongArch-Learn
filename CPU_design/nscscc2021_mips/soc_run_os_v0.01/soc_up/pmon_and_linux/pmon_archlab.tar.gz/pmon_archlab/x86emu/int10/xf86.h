#ifndef _x86_h_
#define _x86_h_

#define CARD8  unsigned char
#define CARD16 unsigned short
#define CARD32 unsigned int
#define pointer void *
#define Bool   int
#define TRUE    1
#define FALSE   0
#define printk printf
#endif
