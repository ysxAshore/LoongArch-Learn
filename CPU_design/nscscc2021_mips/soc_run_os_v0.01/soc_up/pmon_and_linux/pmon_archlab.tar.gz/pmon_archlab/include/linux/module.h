#ifndef __MODULE_H__
#define __MODULE_H__
#define EXPORT_SYMBOL(...)
#define MODULE_LICENSE(...)
struct module{};
#endif

