void tgt_poweroff()
{
printf("arch does not support poweroff\n");
}
